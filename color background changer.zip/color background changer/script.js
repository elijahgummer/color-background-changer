let changeColor = document.getElementById("changeColor");

let colors = ["blue", "red", "yellow", "orange"];

function changeBackgroundColor() {
  let rand = Math.random();
  let totalColors = colors.length;
  let randomIndex = Math.floor(rand * totalColors);
  let randomColor = colors[randomIndex];

  document.body.style.backgroundColor = randomColor;
  document.getElementById("color").innerHTML = randomColor;
  document.querySelector("p").style.color = randomColor;
}

